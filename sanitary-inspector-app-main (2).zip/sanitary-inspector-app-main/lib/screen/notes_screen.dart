import 'package:flutter/material.dart';

class NotesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('📝 Notes')),
      body: Center(child: Text('Notes will be available soon...')),
    );
  }
}
