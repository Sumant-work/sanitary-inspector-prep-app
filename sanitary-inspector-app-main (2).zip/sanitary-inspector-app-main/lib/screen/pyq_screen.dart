import 'package:flutter/material.dart';

class PyqScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('📄 PYQ PDFs')),
      body: Center(child: Text('PYQ content coming soon...')),
    );
  }
}
