# sanitary-inspector-Prep-app
Simple Flutter app to read PDFs and take quizzes for Sanitary Inspector preparation.
